# Canario Lector production-readiness research package v1

State: **research evidence only — no implementation authorization**

Baseline: `ce07da9466a638738c845f7fba152a47e9987a59`  
Researched through: `2026-08-27`

This package follows `notebook/research/PACKAGE_PROTOCOL.md`:

```text
Source Books
-> claims/evidence
-> fit matrix
-> transfers
-> gap audit
-> synthesis
-> fit-bench design candidate
```

It intentionally does **not** contain production code, a model prompt, benchmark gold, or an
implementation candidate.

## Books

- `B01-canario-authority`
- `B02-claimify`
- `B03-claim-quality-metrics`
- `B04-decomposition-context`
- `B05-long-document-processing`
- `B06-langextract`
- `B07-openie-evaluation`
- `B08-structured-output-reliability`
- `B09-source-fidelity`
- `B10-spanish-domain-transfer`

## Synthesis

- `synthesis/claims.csv`
- `synthesis/fit-matrix.csv`
- `synthesis/transfers.csv`
- `synthesis/gap-audit.md`
- `synthesis/BOOK.md`
- `synthesis/FIT_BENCH_DESIGN_CANDIDATE.md`
