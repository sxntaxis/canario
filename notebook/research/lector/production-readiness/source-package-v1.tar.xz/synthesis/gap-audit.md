---
id: CANARIO-LECTOR-READINESS-GAP-AUDIT-001
type: research-gap-audit
state: open-for-fit-bench-design
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Gap audit

## Gaps that still threaten a production decision

1. **No Canario-native comparative measurement yet.** External literature converges on decomposition,
   context preservation and coverage measurement, but does not tell us which bounded orchestration wins
   on Spanish civic records.
2. **Civic focus definition is not frozen.** Canario wants broad recoverability, not all sentences and
   not fact-checking-style editorial check-worthiness. Reference annotation must operationalize
   "material civic assertion" without hiding obscure facts.
3. **No replacement semantic reference is frozen.** Existing LECTOR-002 scopes may be reusable as
   source/scope fixtures, but reference construction was stopped before gold.
4. **Spanish institutional stress is underrepresented in external benchmarks.** Real Costa Rican
   minutes/correspondence/normative/report material is required.
5. **Cross-unit context policy is unmeasured.** Need controlled cases for pronouns, headings,
   conditions, exceptions, cross-references, attribution and facts spanning pages.
6. **Semantic reconciliation policy is open.** Need fact-equivalence, duplicate and qualifier-conflict
   rules that do not use text equality.
7. **Relations/mentions may overload the first model-facing schema.** Benchmark claims/evidence first,
   then measure whether adding mentions/relations degrades claim quality.
8. **No source-fidelity counterfactual lane exists.** Must measure parametric 'correction' of source.
9. **Run-to-run stability is unknown.** Repeat candidate lanes enough to expose stochastic omissions
   and compare repeated-pass versus coverage-directed repair.
10. **Operational trade-offs are unknown.** Record calls, input/output bytes/tokens where observable,
    latency, egress and failure rate separately from semantic quality.

## Gaps that no longer block this research stage

- Structured computation/verification boundaries are already reconciled and implemented.
- Evidence selector/reopening and LECTOR-001 canonical persistence are already bounded.
- Provider-independent SemanticExtractor ownership is already accepted.
- A finite exhaustive document taxonomy is explicitly rejected.
- The benchmark anti-leakage ordering already exists and can be adapted.

## Stop condition for research

Do not authorize production implementation until a fit-bench design can answer all of:

- What exact hypotheses distinguish A0–A5?
- What frozen source/reference fixtures expose each critical failure mode?
- What metrics adjudicate coverage, focus, entailment, context, ambiguity and evidence?
- What thresholds are frozen only after reference counts and before tested extraction?
- What result would select the simplest sufficient orchestration?
