---
id: CANARIO-LECTOR-READINESS-B05_LONG_DOCUMENT_PROCESSING
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Long-document decomposition: DocETL, MapReduce, and multi-needle evidence

## Boundary

Research on why long-context capacity does not by itself guarantee complete extraction and how
divide-and-conquer systems can recover accuracy while introducing their own dependency/conflict risks.

## What the evidence establishes

DocETL reports that single-call document operations can miss relevant information and obtains
21–80%/25–80% accuracy improvements through task/data decomposition and plan evaluation across four
real document tasks. LLM×MapReduce formalizes inter-chunk dependency and conflict as central failure
modes of chunked long-text processing. Sequential-NIAH shows increasing context length and number of
required items sharply degrade retrieval; the best tested model reached 63.15% maximum accuracy in
that benchmark.

## Limits / bias

DocETL is a general agentic document-processing optimizer and can be much heavier than Canario
needs. NIAH benchmarks are synthetic/controlled retrieval stress tests rather than civic extraction.

## Potential Canario transfer

Adopt the empirical requirement to compare decomposition strategies. Adapt explicit handling
of cross-chunk dependency/conflict and coverage auditing. Use whole-document one-shot as a challenger
baseline, not assumed production design.

## Do not import

Do not vendor an agentic query optimizer or generic execution graph before a Canario fit bench
shows that simpler contextual multi-pass extraction is insufficient.

## Unresolved questions

Can a fixed, inspectable Canario pipeline capture most of DocETL's gain without dynamic
agent rewrite? What bounded context envelope preserves cross-page conditions/references?
