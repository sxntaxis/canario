---
id: CANARIO-LECTOR-READINESS-B02_CLAIMIFY
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Claimify / effective factual-claim extraction

## Boundary

ACL 2025 Claimify work and Microsoft Research's implementation description. The source task is
claim extraction from LLM-generated long-form answers, not civic records, but its ambiguity and
decontextualization mechanisms are directly relevant.

## What the evidence establishes

The work evaluates claim extraction through entailment, coverage, and decontextualization.
Claimify uses sentence/context construction, selection of verifiable content, explicit ambiguity
detection/disambiguation, then decomposition into standalone claims. Unresolved ambiguity can be
flagged instead of arbitrarily interpreted. Microsoft reports 99% of Claimify claims entailed by
their source sentence on the evaluated setup and improved balance of included/excluded content.

## Limits / bias

Inputs are primarily LLM-generated answers, mostly English; 'verifiable' and fact-checking focus
are not identical to Canario's broad civic relevance. Reported performance should not be transferred
as a Canario quality expectation.

## Potential Canario transfer

Adapt the staged distinction between source-unit selection, ambiguity resolution, and
decomposition; adapt the requirement that final claims preserve critical context and be independently
understandable.

## Do not import

Do not import Claimify's task definition wholesale, especially a check-worthiness/editorial
filter that could suppress obscure but later-important civic facts.

## Unresolved questions

Can selection be made broad enough for civic recoverability? How much structural/local context
is necessary for Spanish administrative text? Should unresolved ambiguity persist as an explicit
machine-only diagnostic rather than simply dropping the unit?
