---
id: CANARIO-LECTOR-READINESS-B09_SOURCE_FIDELITY
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Source fidelity versus parametric knowledge

## Boundary

Research on grounded generation failures where an LLM either uses unsupported knowledge or
'corrects' the source instead of faithfully representing it.

## What the evidence establishes

Harmful Factuality Hallucination formalizes cases where a model outputs a factually true
'correction' that is unfaithful to the provided source; the paper reports the behavior grows with
model scale in its tests and a simple instruction reduces but does not eliminate it. RLSeek's error
analysis finds explicit source evidence seeking/quotation improves hallucination detection. Work on
structured knowledge also reports models reverting to parametric memory despite sufficient supplied
evidence.

## Limits / bias

These works include summarization/QA/hallucination-detection tasks, not direct Canario Lector
evaluation. Internal mechanistic explanations should not be over-generalized to every model.

## Potential Canario transfer

Create controlled counterfactual source-fidelity cases where the retained civic source contains
a plausible typo/outdated/unusual fact that conflicts with model world knowledge. Require extraction
to preserve what the source says, not silently repair it. Treat exact quotation as required grounding
but separately adjudicate claim entailment.

## Do not import

Never ask the production Lector to 'correct factual errors using your knowledge' for
`source_assertion`.

## Unresolved questions

Should source-fidelity counterfactuals be a hard zero-tolerance certification lane?
How should Canario represent an obviously erroneous source statement while enabling later
Verification/Assessment to refute it?
