---
id: CANARIO-LECTOR-READINESS-B10_SPANISH_DOMAIN_TRANSFER
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Spanish / institutional-domain transfer risk

## Boundary

Evidence relevant to Spanish legal/administrative information extraction and multilingual claim
processing. This is a transfer-risk Book, not proof of a specific Canario extractor.

## What the evidence establishes

Recent Spanish legal work constructs human-validated terminology gold rather than assuming
general IE transfer. A 2026 Spanish court-assistant system combines PDF processing, rule-based
classification, LLM extraction, and explicit post-processing for fragmented/duplicate records,
achieving strong F1 only on bounded tasks such as personal-data extraction. MUCH includes Spanish in
claim-level hallucination evaluation. Portuguese OpenIE benchmarking reports no universally dominant
system and around 40% average F1, illustrating that related-language IE remains nontrivial.

## Limits / bias

Terminology extraction, personal-data fields, hallucination UQ, and Portuguese OIE are not broad
Costa Rican civic claim extraction. Results are useful mainly as evidence that language/domain
transfer must be measured.

## Potential Canario transfer

Require Spanish institutional fixtures and per-language reporting. Include long legal syntax,
formal attribution, cross-references, dates, quantities, negation and conditions. Use human-approved
reference in Spanish.

## Do not import

Do not translate all source text to English as the canonical semantic extraction path merely
because English benchmarks are stronger; translation is a derivative Representation and introduces
another failure surface.

## Unresolved questions

Should a multilingual challenger be benchmarked using the same Spanish prompt versus English
instructions? Which Costa Rican legal/administrative source families best stress syntax without
becoming a product ontology?
