---
id: CANARIO-LECTOR-READINESS-B08_STRUCTURED_OUTPUT_RELIABILITY
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Structured-output reliability and schema breadth

## Boundary

2026 evidence on LLM structured extraction showing that syntactic schema compliance and semantic
extraction correctness are different problems, especially as schemas broaden.

## What the evidence establishes

ContextualAI ExtractBench reports sharp degradation with schema breadth, including 0% valid
output across tested frontier models on a 369-field financial schema. The Structured Output Benchmark
finds near-perfect schema compliance can coexist with much lower value accuracy, especially on
image/audio-derived contexts. SchemaRAG improves extraction by reducing large target schemas.
LLMStructBench and output-format research show prompting/output form can change semantic performance,
not merely parsing convenience.

## Limits / bias

Most tasks are schema-guided field extraction, whereas Canario's broad Claim extraction is
open-schema. Vendor/benchmark setups differ and exact headline numbers are not Canario predictions.

## Potential Canario transfer

Keep model-facing output objects narrow and compositional. Benchmark extraction stages and
semantic correctness separately from JSON validity. Avoid asking one model call to emit Claims,
relations, entities, classifications, assessments and every metadata family at once.

## Do not import

Do not interpret Structured Outputs/constrained decoding as semantic assurance.

## Unresolved questions

What is the smallest model-facing draft contract that preserves enough information for core
validation without increasing schema burden? Should relations/mentions be separate extraction lanes?
