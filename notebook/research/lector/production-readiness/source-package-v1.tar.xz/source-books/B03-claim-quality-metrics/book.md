---
id: CANARIO-LECTOR-READINESS-B03_CLAIM_QUALITY_METRICS
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Claim Extraction for Fact-Checking metrics and FEVERFact

## Boundary

2025 work consolidating scattered claim/fact extraction objectives into a multi-dimensional
evaluation framework and dataset.

## What the evidence establishes

The framework evaluates per-claim Atomicity, Fluency, Decontextualization, and Faithfulness,
and set-level Focus and Coverage. It validates automated metrics against human grading and introduces
an aggregate `F_fact` emphasizing the focus/coverage trade-off.

## Limits / bias

FEVERFact is adapted from contextualized Wikipedia sentences, not long Spanish civic records.
Automatic graders remain approximations and cannot replace a frozen human-approved Canario reference.

## Potential Canario transfer

Adopt the distinction between per-claim quality and set-level coverage/focus. Adapt F_fact-like
reporting only after Canario defines 'material civic information' and freezes threshold policy.

## Do not import

Do not reduce readiness to a single aggregate score or claim count; do not allow strong
atomicity/fluency to hide omissions.

## Unresolved questions

How should Canario define focus without suppressing obscure-but-useful facts? Which metrics can
be automated as diagnostics versus requiring human adjudication?
