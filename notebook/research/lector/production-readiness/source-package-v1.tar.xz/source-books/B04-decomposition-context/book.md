---
id: CANARIO-LECTOR-READINESS-B04_DECOMPOSITION_CONTEXT
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Molecular facts and decomposition/decontextualization trade-offs

## Boundary

A research lineage on how finely to decompose propositions and how to preserve enough context
for independent interpretation/verification.

## What the evidence establishes

Molecular Facts argues fully atomic facts can lose interpretive context and proposes balancing
decontextuality with minimality. DnDScore and Decomposition Dilemmas show decomposition and
decontextualization interact and decomposition can introduce noise or alter downstream verification
performance. Dynamic-decomposition work further shows no universal atomicity policy is optimal for
all verifier/task settings.

## Limits / bias

These papers largely study factuality verification of generated text, not civic extraction.
Their downstream verifier objective is related but not identical to Canario retrieval/correction.

## Potential Canario transfer

Adopt 'self-sufficient minimal proposition' rather than maximal atomization. Benchmark
conditions, attribution, negation and temporal qualifiers as information that may need to remain in
the same Claim even if it increases length.

## Do not import

Do not impose 'one relation = one Claim' or shortest-possible claims as a mechanical rule.

## Unresolved questions

What is the smallest proposition that still supports independent evidence, correction,
retrieval and relationships in Canario? Should some qualifiers be structured fields plus textual
content, or must they remain explicitly in claim text?
