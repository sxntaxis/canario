---
id: CANARIO-LECTOR-READINESS-B06_LANGEXTRACT
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Google LangExtract long-document grounded extraction

## Boundary

Current open-source extraction library used as mechanism prior art for span grounding, chunking,
parallelism, and repeated extraction passes.

## What the evidence establishes

LangExtract maps extractions to source character locations, uses chunking and parallel
processing for long documents, and explicitly supports multiple extraction passes to improve recall.
Its long-text example repeats independent extraction over the full text and merges non-overlapping
results. The project also explicitly allows prompts to leverage model world knowledge.

## Limits / bias

Project documentation is not an independent benchmark. Its default extraction semantics are
entity/schema-oriented and its allowance for world knowledge conflicts with Canario source-assertion
fidelity unless tightly disabled.

## Potential Canario transfer

Adapt exact grounding and the idea of repeated recall passes as a benchmark lane. Study its
chunk/resolver implementation as engineering prior art.

## Do not import

Do not adopt world-knowledge enrichment for `source_assertion`; do not equate exact span
alignment with semantic entailment; do not assume same-prompt stochastic repetition is the best
coverage strategy.

## Unresolved questions

Does a coverage-directed second pass outperform repeated identical passes for Canario?
How should overlapping claim-equivalent outputs be reconciled semantically rather than only by span?
