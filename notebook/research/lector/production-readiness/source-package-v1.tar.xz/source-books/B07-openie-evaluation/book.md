---
id: CANARIO-LECTOR-READINESS-B07_OPENIE_EVALUATION
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Fact-oriented OpenIE evaluation: BenchIE and AnnIE

## Boundary

Open Information Extraction benchmark work focused on exhaustive fact coverage and the problem
that one fact can have multiple acceptable surface realizations.

## What the evidence establishes

BenchIE argues older OpenIE evaluations can be unreliable because gold standards omit valid
surface realizations, and uses fact synsets grouping informationally equivalent extractions. AnnIE
supports constructing complete fact-oriented benchmarks by manually grouping acceptable
realizations.

## Limits / bias

OpenIE typically represents relation tuples and much of the benchmark lineage is sentence-level.
Canario Claims are richer propositions with evidence, qualifiers and revision identity.

## Potential Canario transfer

Adapt fact-equivalence groups for semantic reference/adjudication: gold should identify required
semantic content and mandatory qualifiers/evidence, not one exact canonical sentence.

## Do not import

Do not force Canario's product representation into OpenIE subject-predicate-object tuples or
treat sentence-level completeness as document-level completeness.

## Unresolved questions

How should Canario reference facts encode required qualifiers and allowable paraphrase without
making adjudication arbitrary? Can relation equivalence be scored separately from Claim equivalence?
