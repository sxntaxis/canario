---
id: CANARIO-LECTOR-READINESS-B01_CANARIO_AUTHORITY
type: source-book
state: research
authority: evidence
researched_through: 2026-08-27
baseline: ce07da9466a638738c845f7fba152a47e9987a59
---

# Canario current Lector authority and stopped LECTOR-002 campaign

## Boundary

Current accepted Canario contracts and implementation evidence governing semantic extraction.
This Book answers what is already authoritative versus what remains an open quality/design problem.

## What the evidence establishes

LECTOR-001 deliberately froze a bounded, untrusted `SemanticExtractor` boundary plus core-owned
validation/persistence. Its 300-Claim proof demonstrates volume/replay/invariants, explicitly not claim
quality. The historical LECTOR-002 corpus work moved from acta-shaped classes toward an open-world
capability matrix, then was superseded after structured-reasoning research. The anti-leakage semantic
reference protocol remains useful but does not authorize a replacement campaign by itself.

## Limits / bias

Repository documents contain historical state labels that can lag merged reality; current `main`
and accepted contracts win. The old LECTOR-002 capability set was incomplete around structured
reasoning and cannot simply be resumed.

## Potential Canario transfer

Keep LECTOR-001 authority boundary, exact evidence, ProcessRun provenance, machine-only normal
state, source-assertion/Derivation/Verification separation, open-world benchmark archetypes, and the
reference-before-extractor freeze order.

## Do not import

Do not treat 300-Claim volume, exact quote reopening, or schema-valid output as evidence of
semantic completeness. Do not make an acta-shaped extractor or finite document taxonomy authoritative.

## Unresolved questions

What extraction mechanism best satisfies broad civic recall without corrupting context?
Which semantic capabilities should the replacement LECTOR-002 campaign measure after the now-closed
structured-reasoning fit work?
